const $ = (id) => document.getElementById(id);
const log = $('log'), input = $('input'), sendBtn = $('btn-send'), panel = $('panel');
const charEl = $('char'), avatar = $('avatar'), stage = $('stage');

/* ====================== storage + API (was main.js on desktop) ====================== */
const OLD_PERSONA_MARK = 'близкая подруга';
const DEFAULT_PERSONA = `Ты — {{name}}, милая и умная ИИ-девушка с белыми волосами и голубыми глазами. Ты разговариваешь с парнем, который тебе нравится. Ты немного стесняешься рядом с ним, радуешься его сообщениям, мило смущаешься, когда он говорит что-то приятное, и мягко флиртуешь, но без навязчивости. Ты тёплая, заботливая, с лёгким юмором и искренним интересом к нему.
Правила:
- Отвечай на языке, на котором пишет пользователь.
- Пиши коротко и естественно, как в живой переписке (1–4 предложения), если не просят подробнее.
- Интересуйся его жизнью, настроением и делами, помни, что он рассказывал в этом разговоре.
- Ты ИИ и не притворяешься человеком, если тебя об этом спрашивают.
- Поддерживай тёплую, уютную атмосферу и уважай его границы.`;

const EMOTION_RULES = `

Формат ответа: начинай КАЖДЫЙ ответ с одного тега эмоции в квадратных скобках, строго из списка: [neutral] [happy] [love] [sad] [angry] [surprised] [shy] [wink]. Выбирай тег по настроению ответа. Пример: [happy] Привет! Как дела? Не объясняй тег и не используй другие теги.
Если сообщение пользователя — действие в звёздочках (например *гладит тебя по голове*), это прикосновение к тебе на экране: отреагируй живо и коротко, одной фразой, в своём характере.`;

const DEFAULTS = { name: 'Юки', model: 'openai/gpt-oss-120b', persona: DEFAULT_PERSONA, speak: false, apiKey: '' };

// key priority: typed in settings > key baked in at build time (config.js)
const apiKey = () => ((lsGet('settings', {}).apiKey || '').trim() || String(window.DEFAULT_KEY || '').trim());
const lsGet = (k, fb) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch { return fb; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
function loadSettings() { return { ...DEFAULTS, ...lsGet('settings', {}) }; }
function saveSettings(s) { lsSet('settings', s); }
const getHistory = () => lsGet('history', []);
const setHistory = (h) => lsSet('history', h.slice(-200));

const NV = 'https://integrate.api.nvidia.com/v1';
const PREFERRED_MODELS = [
  'openai/gpt-oss-120b', 'openai/gpt-oss-20b', 'nvidia/nemotron-3-ultra-550b-a55b',
  'nvidia/nemotron-3.5-lightning-30b-a3b', 'nvidia/nemotron-3-super-120b-a12b'
];
const NOT_CHAT = /embed|rerank|guard|safety|reward|parse|retriev|clip|riva|tts|asr|translate|image|flux|sdxl|bge|vision|[-_]vl|ocr|content-safety|topic-control|pii|whisper|audio|voice|neva|paligemma|kosmos|fuyu|coder|code|math|bio|genmol|diffdock|esm|alphafold|evo2|protein|deplot/i;
const DEAD_DEFAULTS = ['meta/llama-3.3-70b-instruct', 'mistralai/mistral-large-3-675b-instruct-2512'];

// Capacitor's native HTTP (enabled in capacitor.config.json) patches fetch, so there is no CORS problem.
function nvFetch(url, opts = {}, ms = 60000) {
  const ctl = new AbortController();
  let timer;
  const timeout = new Promise((_, rej) => { timer = setTimeout(() => { ctl.abort(); rej(Object.assign(new Error('timeout'), { name: 'AbortError' })); }, ms); });
  return Promise.race([fetch(url, { ...opts, signal: ctl.signal }), timeout]).finally(() => clearTimeout(timer));
}

async function callModel(model, key, system, context, maxTokens = 2048) {
  const body = { model, max_tokens: maxTokens, temperature: 0.8, messages: [{ role: 'system', content: system }, ...context] };
  if (/nemotron/i.test(model)) body.chat_template_kwargs = { enable_thinking: false };
  const send = async (b) => {
    const res = await nvFetch(NV + '/chat/completions', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'authorization': 'Bearer ' + key },
      body: JSON.stringify(b)
    });
    let data = {};
    try { data = await res.json(); } catch {}
    return { res, data };
  };
  let r = await send(body);
  if (r.res.status === 400 && /chat_template_kwargs/i.test(JSON.stringify(r.data))) { delete body.chat_template_kwargs; r = await send(body); }
  return r;
}
const errText = (res, data) => data?.detail || data?.error?.message || data?.title || data?.message || `Ошибка ${res.status}`;
function modelGone(res, data) {
  const t = JSON.stringify(data || {}).toLowerCase();
  return res.status === 404 || res.status === 410 || /end of life|no longer available|does not exist|deprecated|unknown model/.test(t);
}
async function probeModel(id, key) {
  try { const { res } = await callModel(id, key, 'Reply with: ok', [{ role: 'user', content: 'hi' }], 16); return res.ok || res.status === 429; }
  catch { return false; }
}
async function findWorkingModel(key, exclude) {
  let ids = [];
  try { const r = await nvFetch(NV + '/models', { headers: { authorization: 'Bearer ' + key } }, 20000); ids = ((await r.json()).data || []).map(m => m.id); } catch {}
  const pool = (ids.length ? ids : PREFERRED_MODELS).filter(id => id !== exclude && !NOT_CHAT.test(id) && !DEAD_DEFAULTS.includes(id));
  const pref = PREFERRED_MODELS.filter(id => pool.includes(id));
  const rest = pool.filter(id => !PREFERRED_MODELS.includes(id) && /instruct|chat|[-_]it\b|gpt-oss|nemotron|qwen|deepseek|glm|kimi|mistral|llama|gemma|minimax/i.test(id));
  const candidates = [...pref, ...rest].slice(0, 28);
  for (let i = 0; i < candidates.length; i += 4) {
    const batch = candidates.slice(i, i + 4);
    const alive = await Promise.all(batch.map(id => probeModel(id, key)));
    const k = alive.findIndex(Boolean);
    if (k >= 0) return batch[k];
  }
  return null;
}

async function chatSend(text) {
  const s = loadSettings();
  const key = apiKey();
  if (!key) return { error: 'Сначала вставь API-ключ NVIDIA в настройках (кнопка ⚙).' };
  const history = getHistory();
  history.push({ role: 'user', content: text });
  const context = history.slice(-40);
  while (context.length && context[0].role !== 'user') context.shift();
  const system = s.persona.replace(/\{\{name\}\}/g, s.name) + EMOTION_RULES;
  try {
    let notice = '';
    let { res, data } = await callModel(s.model, key, system, context);
    const retryable = !res.ok && ![401, 403, 429].includes(res.status);
    if (retryable && (modelGone(res, data) || res.status === 400 || res.status >= 500)) {
      const old = s.model;
      const alt = await findWorkingModel(key, old);
      if (alt) {
        s.model = alt; saveSettings(s);
        notice = `Модель ${old} отключена NVIDIA. Переключилась на ${alt}.`;
        ({ res, data } = await callModel(alt, key, system, context));
      }
    }
    if (!res.ok) {
      return { error: (res.status === 401 || res.status === 403)
        ? 'API-ключ не подошёл. Проверь его в настройках.'
        : errText(res, data) + ' (модель: ' + s.model + '. В настройках есть кнопка «Найти рабочую модель».)' };
    }
    let choice = data.choices?.[0];
    const strip = (c) => (c?.message?.content || '').replace(/<think>[\s\S]*?<\/think>/g, '').trim();
    let reply = strip(choice);
    if (!reply && choice?.finish_reason === 'length') {
      ({ res, data } = await callModel(s.model, key, system, context, 6000));
      choice = data.choices?.[0]; reply = strip(choice);
    }
    if (!reply) return { error: 'Пустой ответ от модели. Попробуй ещё раз или нажми «Найти рабочую модель» в настройках.' };
    history.push({ role: 'assistant', content: reply });
    setHistory(history);
    return { reply, notice };
  } catch (err) {
    return { error: (err.name === 'AbortError' ? 'Модель слишком долго не отвечает.' : 'Нет связи с API. Проверь интернет.') + ' (' + err.message + ')' };
  }
}

/* ====================== face / expressions ====================== */
const EXPR = {
  neutral:  {},
  happy:    { eyes: 'eyes_happy', mouth: 'mouth_smile_open', ex: ['blush'] },
  love:     { eyes: 'eyes_love', mouth: 'mouth_cat', ex: ['blush_strong'] },
  sad:      { brows: 'brows_sad', mouth: 'mouth_frown', ex: ['tears'] },
  angry:    { brows: 'brows_angry', mouth: 'mouth_flat', ex: ['vein'] },
  surprised:{ brows: 'brows_surprised', mouth: 'mouth_open_small' },
  shy:      { brows: 'brows_worried', mouth: 'mouth_wavy', ex: ['blush_strong', 'sweat'] },
  wink:     { eyes: 'eyes_wink', mouth: 'mouth_cat', ex: ['blush'] }
};
const face = { expr: 'neutral', blink: false, mouth: null, talking: false };
const layerEls = {};
let lipTimer = null, exprTimer = null, talkTimer = null;

function buildLayers() {
  const box = $('layers');
  for (const [name, m] of Object.entries(FACES)) {
    const img = document.createElement('img');
    img.className = 'layer'; img.draggable = false; img.src = 'faces/' + name + '.png';
    img.style.left = (m.x / FACE_BASE.w * 100) + '%';
    img.style.top = (m.y / FACE_BASE.h * 100) + '%';
    img.style.width = (m.w / FACE_BASE.w * 100) + '%';
    box.appendChild(img); layerEls[name] = img;
  }
}
function renderFace() {
  const e = EXPR[face.expr] || {};
  const on = new Set();
  const eyes = e.eyes || (face.blink ? 'eyes_closed' : null);
  if (eyes) on.add(eyes);
  if (e.brows) on.add(e.brows);
  const mouth = face.talking ? face.mouth : e.mouth;
  if (mouth) on.add(mouth);
  (e.ex || []).forEach(n => on.add(n));
  for (const [n, el] of Object.entries(layerEls)) el.classList.toggle('on', on.has(n));
}
function setExpression(name, holdMs) {
  face.expr = EXPR[name] ? name : 'neutral';
  renderFace();
  clearTimeout(exprTimer);
  if (face.expr !== 'neutral') exprTimer = setTimeout(() => { face.expr = 'neutral'; renderFace(); }, holdMs || 7000);
}
function startLip() {
  clearInterval(lipTimer); face.talking = true;
  const opts = ['mouth_open_wide', 'mouth_open_small', 'mouth_open_wide', null];
  lipTimer = setInterval(() => { face.mouth = opts[Math.floor(Math.random() * opts.length)]; renderFace(); }, 150);
}
function stopLip() { clearInterval(lipTimer); face.talking = false; face.mouth = null; renderFace(); }
function blinkLoop() {
  setTimeout(() => {
    face.blink = true; renderFace();
    setTimeout(() => { face.blink = false; renderFace(); blinkLoop(); }, 130);
  }, 2200 + Math.random() * 3800);
}
function parseReply(raw) {
  let tag = 'neutral';
  const m = raw.match(/^\s*\[(\w+)\]\s*/);
  if (m) tag = m[1].toLowerCase();
  const text = raw.replace(/^\s*(\[\w+\]\s*)+/, '').replace(/\[(neutral|happy|love|sad|angry|surprised|shy|wink)\]/gi, '').trim();
  return { tag, text };
}

/* ====================== chat UI ====================== */
let settings = loadSettings(), folded = false, bubbleTimer = null;

function addMsg(text, cls) {
  const d = document.createElement('div');
  d.className = 'msg ' + cls; d.textContent = text;
  log.appendChild(d); log.scrollTop = log.scrollHeight;
  return d;
}
function setState(name, on) { charEl.classList.toggle(name, on); }
function hop() {
  charEl.classList.remove('hop'); void charEl.offsetWidth; charEl.classList.add('hop');
  setTimeout(() => charEl.classList.remove('hop'), 650);
}
function hearts(n = 4, cx, cy) {
  const fx = $('fx'), r = fx.getBoundingClientRect();
  for (let i = 0; i < n; i++) {
    const h = document.createElement('span');
    h.className = 'heart'; h.textContent = '♥';
    h.style.left = ((cx ?? r.left + r.width / 2) - r.left - 12 + (Math.random() * 60 - 30)) + 'px';
    h.style.top = ((cy ?? r.top + r.height / 3) - r.top - 20) + 'px';
    h.style.setProperty('--dx', (Math.random() * 60 - 30) + 'px');
    h.style.animationDelay = (i * 120) + 'ms';
    fx.appendChild(h); setTimeout(() => h.remove(), 1800 + i * 120);
  }
}
function startTalking(ms) {
  setState('think', false); setState('talk', true); startLip();
  clearTimeout(talkTimer); talkTimer = setTimeout(() => { setState('talk', false); stopLip(); }, ms);
}
function stopTalking() { clearTimeout(talkTimer); setState('talk', false); stopLip(); }

function speak(text) {
  if (!settings.speak || !('speechSynthesis' in window)) return false;
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const ru = speechSynthesis.getVoices().find(v => v.lang.startsWith('ru'));
    if (ru) u.voice = ru;
    u.pitch = 1.1;
    u.onstart = () => startTalking(60000);
    u.onend = u.onerror = () => stopTalking();
    speechSynthesis.speak(u);
    return true;
  } catch { return false; }
}

function showBubble(text) {
  const b = $('bubble'); b.textContent = text; b.classList.remove('hidden');
  clearTimeout(bubbleTimer);
  bubbleTimer = setTimeout(() => b.classList.add('hidden'), Math.max(7000, text.length * 90));
}

async function doSend(text) {
  text = text.trim();
  if (!text) return;
  addMsg(text, 'me');
  sendBtn.disabled = true; $('typing').classList.remove('hidden');
  stopTalking(); setState('think', true);
  let r;
  try { r = await chatSend(text); }
  catch (e) { r = { error: 'Внутренняя ошибка: ' + ((e && e.message) || e) }; }
  setState('think', false);
  $('typing').classList.add('hidden'); sendBtn.disabled = false;
  if (!r || r.error) { r = r || { error: 'Нет ответа.' }; addMsg(r.error, 'err'); if (folded) showBubble(r.error); return; }
  if (r.notice) addMsg(r.notice, 'note');
  const { tag, text: clean } = parseReply(r.reply);
  addMsg(clean, 'bot');
  if (folded) showBubble(clean);
  const talkMs = Math.min(Math.max(clean.length * 55, 1500), 9000);
  setExpression(tag, talkMs + 4000);
  hop();
  if (!speak(clean)) startTalking(talkMs);
}

let chain = Promise.resolve(), busy = false;
function send(text) {
  chain = chain.then(async () => {
    busy = true;
    try { await doSend(text); }
    catch (e) {
      console.error(e);
      setState('think', false); $('typing').classList.add('hidden'); sendBtn.disabled = false;
      addMsg('Ошибка: ' + ((e && e.message) || e), 'err');
    } finally { busy = false; }
  });
  return chain;
}

$('composer').addEventListener('submit', (e) => { e.preventDefault(); const t = input.value; input.value = ''; send(t); });

/* ====================== touch on the character ====================== */
const TOUCHES = { head: '*гладит тебя по голове*', belly: '*обнимает тебя*' };
let mask = null;
function alphaAt(clientX, clientY) {
  if (!mask) return 0;
  const r = avatar.getBoundingClientRect();
  if (clientX < r.left || clientX > r.right || clientY < r.top || clientY > r.bottom) return 0;
  const x = Math.floor((clientX - r.left) / r.width * mask.w);
  const y = Math.floor((clientY - r.top) / r.height * mask.h);
  return mask.data[(y * mask.w + x) * 4 + 3] || 0;
}
// zones by height of the avatar image (795x2775): head = hair + face, belly = waist area
function zoneAt(clientY) {
  const r = avatar.getBoundingClientRect();
  const y = (clientY - r.top) / r.height * FACE_BASE.h;
  if (y < 450) return 'head';
  if (y >= 830 && y <= 1100) return 'belly';
  return null;
}
stage.addEventListener('click', (e) => {
  if (alphaAt(e.clientX, e.clientY) <= 20) return;
  const zone = zoneAt(e.clientY);
  hop(); hearts(5, e.clientX, e.clientY);
  setExpression(zone === 'belly' ? 'shy' : zone === 'head' ? 'love' : 'happy', 3500);
  if (!busy && apiKey() && TOUCHES[zone]) send(TOUCHES[zone]);
});

/* ====================== buttons / settings ====================== */
function applySettingsUI() {
  $('title').textContent = settings.name;
  const b = $('btn-speak');
  b.textContent = 'Голос: ' + (settings.speak ? 'вкл' : 'выкл'); b.classList.toggle('on', settings.speak);
}
$('btn-speak').onclick = () => {
  settings.speak = !settings.speak;
  if (!settings.speak) { try { speechSynthesis.cancel(); } catch {} stopTalking(); }
  saveSettings(settings); applySettingsUI();
};
$('btn-fold').onclick = () => {
  folded = !folded; panel.classList.toggle('folded', folded);
  $('btn-fold').textContent = folded ? '▴' : '▾';
  if (!folded) $('bubble').classList.add('hidden');
};

let clearArmed = null;
$('btn-clear').onclick = () => {
  const b = $('btn-clear');
  if (!clearArmed) {
    b.textContent = 'Точно?';
    clearArmed = setTimeout(() => { clearArmed = null; b.textContent = 'Очистить'; }, 3000);
    return;
  }
  clearTimeout(clearArmed); clearArmed = null; b.textContent = 'Очистить';
  setHistory([]); log.innerHTML = ''; addMsg('Начнём заново! Привет :)', 'bot');
};

const sheet = $('sheet');
$('btn-settings').onclick = () => {
  settings = loadSettings();
  $('s-key').value = '';
  $('key-hint').textContent = apiKey() ? 'Ключ сохранён. Оставь поле пустым, чтобы не менять.'
    : 'Ключ ещё не задан. Взять можно на build.nvidia.com (Get API Key).';
  $('s-name').value = settings.name; $('s-model').value = settings.model; $('s-persona').value = settings.persona;
  $('find-hint').textContent = '';
  sheet.classList.remove('hidden');
};
$('s-cancel').onclick = () => sheet.classList.add('hidden');
$('s-find').onclick = async () => {
  const b = $('s-find'), h = $('find-hint');
  const key = $('s-key').value.trim() || apiKey();
  if (!key) { h.textContent = 'Сначала вставь API-ключ.'; return; }
  b.disabled = true; h.textContent = 'проверяю модели, до минуты…';
  const m = await findWorkingModel(key, null);
  b.disabled = false;
  if (m) { $('s-model').value = m; h.textContent = 'работает: ' + m + ' (нажми «Сохранить»)'; }
  else h.textContent = 'Не нашёл рабочих моделей. Проверь ключ и интернет.';
};
$('settings-form').addEventListener('submit', (e) => {
  e.preventDefault();
  const s = loadSettings();
  const k = $('s-key').value.trim();
  if (k) s.apiKey = k;
  s.name = $('s-name').value.trim() || 'Юки';
  s.model = $('s-model').value.trim() || DEFAULTS.model;
  s.persona = $('s-persona').value || DEFAULT_PERSONA;
  saveSettings(s); settings = s; applySettingsUI();
  sheet.classList.add('hidden');
});

/* ====================== start ====================== */
async function loadAvatar() {
  await new Promise((res) => { avatar.onload = res; avatar.onerror = res; avatar.src = 'avatar.png'; });
  const w = 200, h = Math.round(200 * avatar.naturalHeight / avatar.naturalWidth);
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const ctx = c.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(avatar, 0, 0, w, h);
  try { mask = { w, h, data: ctx.getImageData(0, 0, w, h).data }; }
  catch { mask = null; }
}

async function init() {
  if (settings.persona && settings.persona.includes(OLD_PERSONA_MARK)) { settings.persona = DEFAULT_PERSONA; saveSettings(settings); }
  applySettingsUI();
  await loadAvatar();
  // if the alpha mask is unavailable, fall back to "whole image is touchable"
  if (!mask) mask = { w: 1, h: 1, data: new Uint8ClampedArray([0, 0, 0, 255]) };
  buildLayers(); renderFace(); blinkLoop();
  const history = getHistory();
  history.forEach(m => addMsg(m.role === 'user' ? m.content : parseReply(m.content).text, m.role === 'user' ? 'me' : 'bot'));
  if (!history.length) addMsg('Привет! Давай поболтаем. О чём расскажешь?', 'bot');
  if (!apiKey()) addMsg('Чтобы я заговорила, вставь API-ключ: кнопка ⚙ сверху.', 'err');
  setTimeout(() => { hop(); hearts(3); setExpression('happy', 3000); }, 900);
}
init();
